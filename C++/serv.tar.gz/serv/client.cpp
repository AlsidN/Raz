#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <string.h>
#include <string>

#include "procedure.h"

using namespace std;


int main()
{
 
  string str;
  
  int port = 54000;
  string ipAddress = "127.0.0.1";
    
  int buf_input[6] = {};
   

  while(true){
     
    cout<<"input number 1 :"<<endl;
    cin>>buf_input[0];   
      
    if(buf_input[0] != 0){  
        cout<<"input step 1 :"<<endl; 
        cin>>buf_input[1];
        if(buf_input[1] != 0) {
           break;
        }
        continue;    
    }   

  }
  
  while(true){
     
    cout<<"input number 2 :"<<endl;
    cin>>buf_input[2];   
      
    if(buf_input[2] != 0){  
        cout<<"input step 2 :"<<endl; 
        cin>>buf_input[3];
        if(buf_input[3] != 0) {
           break;
        }
        continue;    
    }   

  }
  
  while(true){
     
    cout<<"input number 3 :"<<endl;
    cin>>buf_input[4];   
      
    if(buf_input[4] != 0){  
        cout<<"input step 3 :"<<endl; 
        cin>>buf_input[5];
        if(buf_input[5] != 0) {
           break;
        }
        continue;    
    }   

  }
  
  string command = "export seq";
  string com;
  cout<<"Введите export seq для отправки"<<endl;
  while(true){
     
      getline(cin,com);
      if(command == com) {
        break;   
      }
      continue;
  }
  
    // Превращаем введенные символы в строку для передачи
    for(int n: buf_input){
     
      str += to_string(n);
      str +=" ";
    }
     cout<<"Вывод : "<<endl;
     cout<<str<<endl;
     
    
    //	Создаем сокет
    int sock = Socket(AF_INET, SOCK_STREAM, 0);
    
    sockaddr_in hint;
    hint.sin_family = AF_INET;
    hint.sin_port = htons(port);
    inet_pton(AF_INET, ipAddress.c_str(), &hint.sin_addr);

    //	Соединяемся с сервером
    int connectRes = connect(sock, (sockaddr*)&hint, sizeof(hint));
    if (connectRes == -1)
    {
        return 1;
    }
////////////////////////////////////////
        
     char buf[11];
         
       while(true){   
             
         // Отправляем на сервер
        int sendRes = send(sock, str.c_str(), str.size(), 0);
        if (sendRes == -1)
        {
            cout << "Не может отправить на сервер ";
            //continue;
        }

        // Ждем ответа от сервера
        memset(buf, 0, 11);
        int bytesReceived = recv(sock, buf, 11, 0);
        if (bytesReceived == -1)
        {
            cout << "Ошибка при получении ответа от сервера\r\n";
        }
        else
        {
           //Показываем ответ сервера
            cout << "SERVER> " << string(buf, bytesReceived) << "\r\n";
        }
    
     cin >>buf_input[0];
    
       }
    //	 Закрываем сокет
    close(sock);

    return 0;
}
