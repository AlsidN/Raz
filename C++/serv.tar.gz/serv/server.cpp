
#include "procedure.h"
#include <iostream>
#include <typeinfo>
#include <thread>
#include <mutex>
#include <string>
using namespace std;

struct multArg {
    
   int m_nsd;  // id сокета
   int m_num;  // Номер клиента 
    
} m_arg;

thread tr[5];// 5 потоков
mutex mut;

 int fd; // Дескриптор клиента

void thread_func( struct multArg *t); // Поток


int main()
{
         
    sockaddr_in client; // Для клиента

    // Создаем сокет
    int server = Socket(AF_INET, SOCK_STREAM, 0);
    
    //Связываем ip и порт с сокетом
    sockaddr_in hint;
   
    hint.sin_family = AF_INET;
    hint.sin_port = htons(54000);
    Inet_pton(AF_INET, "0.0.0.0", &hint.sin_addr);
 
    Bind(server, (sockaddr*)&hint, sizeof(hint));
 
    // Устанавливаем число клиентов (1024)
    Listen(server, SOMAXCONN);
    
    
   //---------------------------------------// 
 
    struct multArg m_arg; 
    struct multArg *m = &m_arg;
   
   
    socklen_t clientSize;
   
   
    mut.lock();
   
            
    for (int i = 0; i < 5; i++)
    {      
        fd = Accept(server, (sockaddr*)&client, &clientSize);
        
        m_arg.m_nsd = fd;
        m_arg.m_num = i;
          
        tr[i]=thread(thread_func,m);
        
    }
   
     
    for (int i = 0; i < 5; i++)
    {
       tr[i].join();
    }
      
    mut.unlock();
       
    // Больше не нужен
    close(server);
 
    return 0;
}


void thread_func(struct multArg *t) {
  
    char buf_from[11];
    char ch_mass[6] = {};// Данные без пробелов
    
    string s; // Для промежуточного преобразования
    string end_string; // Строка для отправки клиенту   
        
    
    // Массивы для передачи в функцию SUMMA()
    int inum[3] = {}; //Основные числа
    int istep[3] = {}; //Шаги для них
   
        
    int q = 0; //Счетчик для int inum[3]
    int r = 1; //Счетчик для int istep[3]
    
    int nsd; //
    int num; // Номер клиента
    
    
    nsd = t->m_nsd;
    num = t->m_num;
    
    memset(buf_from, 0, 11);
 
    //-------- Работа с клиентом -------------//  
      
        // Ждем передачи данных 
        int bytesReceived = recv(nsd, buf_from, 11, 0);
        if (bytesReceived == -1)
        {
            cerr << "Error in recv(). Quitting" << endl;
           
        }
 
        if (bytesReceived == 0)
        {
            cout << "Client disconnected " << endl;
           
        }
         
       
        cout <<"  Клиент № "<<num<<endl<<"Полученная строка : "<< string(buf_from, 0, bytesReceived) << endl;
  
        //Превращение в строку без пробелов
        for(auto a : buf_from) {
                   
           if(a == ' ') {
               continue;
           }
           s += a;
         }
                  
         //Преобразуем string в char
          strcpy(ch_mass,s.c_str());
       
         //Преобразуем в int  - '0'
          for(int i = 0;i<3;i++){
        
           inum[i] = ch_mass[q] - '0';
           istep[i] = ch_mass[r]- '0';
           q+=2; r+=2;
       
           }
                  
          
           //Нормализует результат
           int buffer[3] = {};
          
           for(int i =0;i<3;i++){
               buffer[i] = inum[i] + istep[i];
           }
                           
        
            
           for(auto x: buffer){
               end_string += to_string(x);
               end_string += ' ';
           }
           cout<<"После операции : "<<end_string<<endl;
          
          
           //Отправляем ответ клиенту  
          send(fd, end_string.c_str(), 6, 0); 

  close(nsd);

}

